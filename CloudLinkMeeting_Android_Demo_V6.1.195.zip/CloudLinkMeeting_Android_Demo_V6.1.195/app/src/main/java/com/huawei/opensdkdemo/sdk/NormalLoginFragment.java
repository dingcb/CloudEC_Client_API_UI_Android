package com.huawei.opensdkdemo.sdk;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.text.Layout;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.huawei.cloudlink.openapi.api.CLMCompleteHandler;
import com.huawei.cloudlink.openapi.api.CLMResult;
import com.huawei.cloudlink.openapi.api.CloudLinkSDK;
import com.huawei.opensdkdemo.DemoUtil;
import com.huawei.opensdkdemo.R;

public class NormalLoginFragment extends DialogFragment {
    public final static String TAG = "NormalLoginFragment";
    View rootView;
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        rootView = inflater.inflate(R.layout.sdk_normal_login, container, false);

        Button joinBtn = rootView.findViewById(R.id.btn_2);
        joinBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                login(v);
            }
        });
        return rootView;
    }
    private void login(View v){
        TextView portView = rootView.findViewById(R.id.server_port);
        String portString = portView.getText().toString();
        if (portString.equals("")){
            portString = portView.getHint().toString();
        }
        int serverPort = Integer.parseInt(portString);

        TextView addressView = rootView.findViewById(R.id.server_address);
        String serverAddress =  addressView.getText().toString();
        if (serverAddress.equals("")){
            serverAddress =  addressView.getHint().toString();
        }

        TextView accountView =  rootView.findViewById(R.id.account);
        String account = accountView.getText().toString();
        if (TextUtils.isEmpty(account)){
            account = accountView.getHint().toString();
        }

        TextView passwordView =  rootView.findViewById(R.id.password);
        String password =  passwordView.getText().toString();
        if (password.equals("")){
            password =  passwordView.getHint().toString();
        }
        DemoUtil.getInstance().showLoadingDialog(getContext());
        CloudLinkSDK.getOpenApi().clmLogin(serverPort, serverAddress, account, password,
                new CLMCompleteHandler() {
                    @Override
                    public void onCompleted(CLMResult result) {
                        DemoUtil.getInstance().dismissLoadingDialog();
                        if (result.getCode() == 0){
                            DemoUtil.showToast(getContext(),"登录成功");
                        }else {
                            Log.e(TAG,"login fail" + result.getMessage());
                            DemoUtil.showToast(getContext(),"登录失败:" + result.getMessage());
                        }
                    }
                });
    }
}

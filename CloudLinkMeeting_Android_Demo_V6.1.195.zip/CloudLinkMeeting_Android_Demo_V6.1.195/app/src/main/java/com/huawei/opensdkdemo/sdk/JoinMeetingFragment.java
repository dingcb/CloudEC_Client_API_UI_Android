package com.huawei.opensdkdemo.sdk;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.huawei.cloudlink.openapi.api.CLMCompleteHandler;
import com.huawei.cloudlink.openapi.api.CLMResult;
import com.huawei.cloudlink.openapi.api.CloudLinkSDK;
import com.huawei.cloudlink.openapi.api.OpenApiConst;
import com.huawei.opensdkdemo.DemoUtil;
import com.huawei.opensdkdemo.R;

public class JoinMeetingFragment extends DialogFragment {
    public final static String TAG = "JoinMeetingFragment";
    View rootView;
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        rootView = inflater.inflate(R.layout.sdk_join_conf, container, false);

        Button joinBtn = rootView.findViewById(R.id.join_btn);
        joinBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                joinConf(v);
            }
        });
        return rootView;
    }
    private void joinConf(View view){
        TextView idView = rootView.findViewById(R.id.meeting_id);
        TextView passView = rootView.findViewById(R.id.meeting_pass);
        String mId = idView.getText().toString();
        String passCode = passView.getText().toString();
        if (TextUtils.isEmpty(mId)){
            DemoUtil.showToast(getContext(),"会议ID不能为空");
            return;
        }
        CloudLinkSDK.getOpenApi().clmJoinMeetingById(mId, passCode, this.completeHandler);
    }
    private CLMCompleteHandler completeHandler = new CLMCompleteHandler() {
        @Override
        public void onCompleted(CLMResult result) {
             if(result.getCmd().equals(OpenApiConst.OPEN_EVENT_JOIN_MEETING_BY_ID)){
                Log.i(TAG,"join meeting result" + result.getMessage());
                if (result.getCode() != 0){
                    Log.e(TAG,"join meeting fail" + result.getMessage());
                    DemoUtil.showToast(getContext(), "入会失败："+ result.getMessage());
                }
            }
        }
    };
}

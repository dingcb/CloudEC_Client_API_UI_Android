package com.huawei.cloudlinkmeetingdemo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.huawei.cloudlink.openapi.api.CLMCompleteHandler;
import com.huawei.cloudlink.openapi.api.CLMParticipant;
import com.huawei.cloudlink.openapi.api.CLMResult;
import com.huawei.cloudlink.openapi.api.CloudLinkSDK;
import com.huawei.cloudlink.openapi.api.OpenApiConst;

import java.util.HashSet;

public class DemoActivity extends Activity {
    private AlertDialog alertDialog;
    private final String TAG = "DemoActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo);
    }

    public void init(View view){
        this.showLoadingDialog();
        CloudLinkSDK.getOpenApi().clmInit(getApplication(), this, new CLMCompleteHandler() {
            @Override
            public void onCompleted(CLMResult result) {
                DemoActivity.this.dismissLoadingDialog();
                Toast.makeText(DemoActivity.this,"初始化成功",Toast.LENGTH_LONG).show();

            }
        });
    }
    public void login(View view){
        TextView portView = findViewById(R.id.server_port);
        String portString = portView.getText().toString();
        if (portString.equals("")){
            portString = portView.getHint().toString();
        }
        int serverPort = Integer.parseInt(portString);

        TextView addressView = findViewById(R.id.server_address);
        String serverAddress =  addressView.getText().toString();
        if (serverAddress.equals("")){
            serverAddress =  addressView.getHint().toString();
        }

        TextView accountView = findViewById(R.id.account);
        String account = accountView.getText().toString();
        if (account.equals("")){
            account = accountView.getHint().toString();
        }

        TextView passwordView = findViewById(R.id.password);
        String password =  passwordView.getText().toString();
        if (password.equals("")){
            password =  passwordView.getHint().toString();
        }
        this.showLoadingDialog();
        CloudLinkSDK.getOpenApi().clmLogin(serverPort, serverAddress, account, password,
                new CLMCompleteHandler() {
                    @Override
                    public void onCompleted(CLMResult result) {
                        DemoActivity.this.dismissLoadingDialog();
                        if (result.getCode() == 0){
                            Toast.makeText(DemoActivity.this,"登录成功",Toast.LENGTH_LONG).show();
                        }else {
                            Log.e(TAG,"login fail" + result.getMessage());
                            Toast.makeText(DemoActivity.this,"登录失败"+ result.getMessage(),Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }
    public void createConf(View view){
        TextView subjectView = findViewById(R.id.subject);
        String subject = subjectView.getText().toString();
        if (TextUtils.isEmpty(subject)){
            subject =  subjectView.getHint().toString();
        }
        RadioButton audioBtn = findViewById(R.id.radio_audio);
        int type = audioBtn.isChecked()?1:19;
        Switch needPasswordSwitch = this.findViewById(R.id.switch_need_password);
        boolean needPassword = needPasswordSwitch.isChecked();
        Switch needWithMemberSwitch = this.findViewById(R.id.switch_with_attend);
        boolean needWithMember = needWithMemberSwitch.isChecked();
        if (needWithMember){
            TextView nameView = findViewById(R.id.attend_name);
            String name = nameView.getText().toString();
            if (TextUtils.isEmpty(name)){
                name =  nameView.getHint().toString();
            }
            TextView numberView = findViewById(R.id.attend_number);
            String number = numberView.getText().toString();
            if (TextUtils.isEmpty(number)){
                number =  numberView.getHint().toString();
            }
            CLMParticipant member = new CLMParticipant(number,name);
            HashSet<CLMParticipant> members = new HashSet<>(1);
            members.add(member);
            CloudLinkSDK.getOpenApi().clmCreateMeetingWithMembers(subject,type,needPassword,members,this.completeHandler);
        }else {
            CloudLinkSDK.getOpenApi().clmCreateMeeting(subject, type, needPassword, this.completeHandler);
        }
    }
    public void joinConfById(View view){
        TextView idView = findViewById(R.id.meeting_id);
        TextView passView = findViewById(R.id.meeting_pass);
        String mId = idView.getText().toString();
        String passCode = passView.getText().toString();
        if (TextUtils.isEmpty(mId)){
            Toast.makeText(this,"会议ID不能为空",Toast.LENGTH_LONG).show();
            return;
        }
        CloudLinkSDK.getOpenApi().clmJoinMeetingById(mId, passCode, this.completeHandler);
    }
    public void anonymousJoinMeeting(View view){
        TextView addressView = findViewById(R.id.anonymous_server_address);
        String serverAddress =  addressView.getText().toString();
        if (serverAddress.equals("")){
            serverAddress =  addressView.getHint().toString();
        }
        TextView portView = findViewById(R.id.anonymous_server_port);
        String portString = portView.getText().toString();
        if (portString.equals("")){
            portString = portView.getHint().toString();
        }
        TextView confIdView = findViewById(R.id.anonymous_conf_id);
        String confId = confIdView.getText().toString();
        Switch micSwitch = findViewById(R.id.switch_open_mic);
        boolean openMic = micSwitch.isChecked();
        Switch cameraSwitch = findViewById(R.id.switch_open_camera);
        boolean openCamera = cameraSwitch.isChecked();
        TextView confEnterCodeView = findViewById(R.id.anonymous_enter_code);
        String enterCode = confEnterCodeView.getText().toString();
        TextView nameView = findViewById(R.id.anonymous_name);
        String name = nameView.getText().toString();
        if (name.equals("")){
            name = nameView.getHint().toString();
        }
        if (!confId.isEmpty()){
            try {
                Uri.Builder builder = new Uri.Builder()
                        .scheme("cloudlink")
                        .authority("welinksoftclient")
                        .path("h5page")
                        .appendQueryParameter("page","joinConfByLink")
                        .appendQueryParameter("server_url",serverAddress)
                        .appendQueryParameter("port",portString)
                        .appendQueryParameter("conf_id",confId)
                        .appendQueryParameter("enter_code",enterCode)
                        .appendQueryParameter("name",name)
                        .appendQueryParameter("open_mic",String.valueOf(openMic))
                        .appendQueryParameter("open_camera",String.valueOf(openCamera));
                this.openCloudLinkWithURL(builder.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    }
    public void openCloudLink(View view){
        if (packageInstalled("com.huawei.CloudLink")){
            String startUrl = "cloudlink://welinksoftclient/h5page?page=launch";
            openCloudLinkWithURL(startUrl);
        }else {
            Toast.makeText(this,"应用未安装",Toast.LENGTH_LONG).show();
        }
    }
    private void  openCloudLinkWithURL(String url){
        Intent intent = new Intent();
        intent.setData(Uri.parse(url));
//        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
    private boolean packageInstalled(String packageName){
        PackageInfo packageInfo = null;
        try {
            packageInfo = getPackageManager().getPackageInfo(packageName,0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return packageInfo != null;
    }
    public void showChooseAttend(View view){
        Switch attendSwitch = findViewById(R.id.switch_with_attend);
        View attendView = findViewById(R.id.attend_view);
        attendView.setVisibility(attendSwitch.isChecked()?View.VISIBLE:View.GONE);
    }
    private CLMCompleteHandler completeHandler = new CLMCompleteHandler() {
        @Override
        public void onCompleted(CLMResult result) {
            if (result.getCmd().equals(OpenApiConst.OPEN_EVENT_CREATE_MEETING)){
                Log.i(TAG,"create meeting result" + result.getMessage());
                if (result.getCode() != 0){
                    Log.e(TAG,"create meeting fail" + result.getMessage());
                }
            }else if(result.getCmd().equals(OpenApiConst.OPEN_EVENT_JOIN_MEETING_BY_ID)){
                Log.i(TAG,"join meeting result" + result.getMessage());
                if (result.getCode() != 0){
                    Log.e(TAG,"join meeting fail" + result.getMessage());
                }
            }
        }
    };
    public void showLoadingDialog() {
        if (alertDialog == null){
            alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable());
            alertDialog.setCancelable(false);
            alertDialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
                @Override
                public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                    return keyCode == KeyEvent.KEYCODE_SEARCH || keyCode == KeyEvent.KEYCODE_BACK;
                }
            });
        }
        alertDialog.show();
        alertDialog.setContentView(R.layout.loading_alert);
        alertDialog.setCanceledOnTouchOutside(false);
    }

    public void dismissLoadingDialog() {
        if (null != alertDialog && alertDialog.isShowing()) {
            alertDialog.dismiss();
        }
    }
}


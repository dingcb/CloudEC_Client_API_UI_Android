package com.huawei.opensdkdemo.sdk;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.huawei.cloudlink.openapi.api.CLMCompleteHandler;
import com.huawei.cloudlink.openapi.api.CLMResult;
import com.huawei.cloudlink.openapi.api.CloudLinkSDK;
import com.huawei.opensdkdemo.DemoActivity;
import com.huawei.opensdkdemo.DemoApplication;
import com.huawei.opensdkdemo.DemoUtil;
import com.huawei.opensdkdemo.R;

public class SSOLoginFragment extends BaseDialogFragment {
    public final static String TAG = "SSOLoginFragment";
    View rootView;
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        rootView = inflater.inflate(R.layout.sdk_sso_login, container, false);

        Button joinBtn = rootView.findViewById(R.id.sso_login_btn);
        joinBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                login(v);
            }
        });
        return rootView;
    }
    private void login(View v){
        TextView domainView = rootView.findViewById(R.id.ssologin_company_domain);
        String domain = domainView.getText().toString();
        if(domain.equals("")) {
            domain = domainView.getHint().toString();
        }
        TextView oauthCodeView = rootView.findViewById(R.id.ssologin_code);
        String userTicket = oauthCodeView.getText().toString();
        if(userTicket.equals("")) {
            userTicket = oauthCodeView.getHint().toString();
        }
        showLoading();
        CloudLinkSDK.getOpenApi().clmSSOLogin(domain, userTicket, new CLMCompleteHandler() {
            @Override
            public void onCompleted(CLMResult result) {
                dismissLoading();
                if (result.getCode() == 0) {
                    DemoUtil.showToast(getContext(),"登录成功");
                } else {
                    Log.e(TAG, "sso login fail" + result.getMessage());
                    DemoUtil.showToast(getContext(),"登录失败" + result.getMessage());
                }
            }
        });
    }
}

package com.huawei.opensdkdemo.sdk;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;

import com.huawei.cloudlink.openapi.api.CLMCompleteHandler;
import com.huawei.cloudlink.openapi.api.CLMParticipant;
import com.huawei.cloudlink.openapi.api.CLMResult;
import com.huawei.cloudlink.openapi.api.CloudLinkSDK;
import com.huawei.cloudlink.openapi.api.OpenApiConst;
import com.huawei.opensdkdemo.DemoActivity;
import com.huawei.opensdkdemo.DemoApplication;
import com.huawei.opensdkdemo.DemoUtil;
import com.huawei.opensdkdemo.R;

import java.util.HashSet;

public class CreateMeetingFragment extends BaseDialogFragment {
    public final static String TAG = "CreateMeetingFragment";
    View rootView;
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        rootView = inflater.inflate(R.layout.sdk_create_conf, container, false);

        Button createBtn = rootView.findViewById(R.id.create_conf);
        createBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                createConf();
            }
        });
        Switch attendChooseSwitch = rootView.findViewById(R.id.switch_with_attend);
        attendChooseSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showChooseAttend();
            }
        });
        View attendView = rootView.findViewById(R.id.attend_view);
        attendView.setVisibility(attendChooseSwitch.isChecked()?View.VISIBLE:View.GONE);

        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
        Switch attendSwitch = rootView.findViewById(R.id.switch_with_attend);
        View attendView = rootView.findViewById(R.id.attend_view);
        attendView.setVisibility(attendSwitch.isChecked()?View.VISIBLE:View.GONE);
    }

    private void createConf(){
        TextView subjectView = rootView.findViewById(R.id.subject);
        String subject = subjectView.getText().toString();
        if (TextUtils.isEmpty(subject)){
            subject =  subjectView.getHint().toString();
        }
        RadioButton audioBtn = rootView.findViewById(R.id.radio_audio);
        int type = audioBtn.isChecked()?1:19;
        Switch needPasswordSwitch = rootView.findViewById(R.id.switch_need_password);
        boolean needPassword = needPasswordSwitch.isChecked();
        Switch needWithMemberSwitch = rootView.findViewById(R.id.switch_with_attend);
        boolean needWithMember = needWithMemberSwitch.isChecked();
        if (needWithMember){
            TextView nameView = rootView.findViewById(R.id.attend_name);
            String name = nameView.getText().toString();
            if (TextUtils.isEmpty(name)){
                name =  nameView.getHint().toString();
            }
            TextView numberView = rootView.findViewById(R.id.attend_number);
            String number = numberView.getText().toString();
            if (TextUtils.isEmpty(number)){
                number =  numberView.getHint().toString();
            }
            CLMParticipant member = new CLMParticipant(number,name);
            HashSet<CLMParticipant> members = new HashSet<>(1);
            members.add(member);
            showLoading();
            CloudLinkSDK.getOpenApi().clmCreateMeetingWithMembers(subject,type,needPassword,members,this.completeHandler);
        }else {
            showLoading();
            CloudLinkSDK.getOpenApi().clmCreateMeeting(subject, type, needPassword, this.completeHandler);
        }
    }
    private CLMCompleteHandler completeHandler = new CLMCompleteHandler() {
        @Override
        public void onCompleted(CLMResult result) {
            if (result.getCmd().equals(OpenApiConst.OPEN_EVENT_CREATE_MEETING)){
                dismissLoading();
                Log.i(TAG,"create meeting result" + result.getMessage());
                if (result.getCode() != 0){
                    Log.e(TAG,"create meeting fail" + result.getMessage());
                    DemoUtil.showToast(getContext(), "创会失败："+ result.getMessage());
                }
            }
        }
    };
    public void showChooseAttend(){
        Switch attendSwitch = rootView.findViewById(R.id.switch_with_attend);
        View attendView = rootView.findViewById(R.id.attend_view);
        attendView.setVisibility(attendSwitch.isChecked()?View.VISIBLE:View.GONE);
    }
}

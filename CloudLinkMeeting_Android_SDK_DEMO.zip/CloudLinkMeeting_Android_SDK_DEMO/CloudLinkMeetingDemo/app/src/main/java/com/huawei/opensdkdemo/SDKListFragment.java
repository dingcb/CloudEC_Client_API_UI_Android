package com.huawei.opensdkdemo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v4.app.DialogFragment;
import android.util.Log;

import com.huawei.cloudlink.openapi.api.CLMCompleteHandler;
import com.huawei.cloudlink.openapi.api.CLMConfig;
import com.huawei.cloudlink.openapi.api.CLMNotifyHandler;
import com.huawei.cloudlink.openapi.api.CLMResult;
import com.huawei.cloudlink.openapi.api.CloudLinkSDK;
import com.huawei.opensdkdemo.sdk.ApiPageModel;
import com.huawei.opensdkdemo.sdk.CallFragment;
import com.huawei.opensdkdemo.sdk.CreateMeetingFragment;
import com.huawei.opensdkdemo.sdk.JoinMeetingFragment;
import com.huawei.opensdkdemo.sdk.NormalLoginFragment;
import com.huawei.opensdkdemo.sdk.SSOLoginFragment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SDKListFragment extends BaseListFragment {
    public final static String TAG = "SDKListFragment";
    private List<String> titles = Arrays.asList("初始化","登录","SSO登录","创建会议","加入会议","呼叫");
    private List<DialogFragment> fragments = Arrays.asList(
            null,
            new NormalLoginFragment(),
            new SSOLoginFragment(),
            new CreateMeetingFragment(),
            new JoinMeetingFragment(),
            new CallFragment());
    @Override
    public List<ApiPageModel> getItems() {
        List<ApiPageModel> models = new ArrayList<>();
        for (int i = 0; i < titles.size(); i ++){
            ApiPageModel item = new ApiPageModel();
            item.name = titles.get(i);
            item.page = fragments.get(i);
            models.add(item);
        }
        return models;
    }

    @Override
    public void handleItemClick(int position, ApiPageModel data) {
        if (position == 0){
            init();
        }else {
            if (data.page != null){
               DialogFragment f =  (DialogFragment) data.page;
               if (!f.isAdded()){
                   f.show(getActivity().getSupportFragmentManager(), null);
               }
            }else {
                Log.e("SDKListFragment", "not found page");

            }
        }
    }
    private void init(){
        DemoUtil.getInstance().showLoadingDialog(getContext());
        CloudLinkSDK.getOpenApi().clmInit(getActivity().getApplication(), getContext(),"openSDKDemo", new CLMCompleteHandler() {
            @Override
            public void onCompleted(CLMResult result) {
                DemoUtil.getInstance().dismissLoadingDialog();
                if (result.getCode() == 0){
                    // 初始化成功
                    DemoUtil.showToast(getContext(), "初始化成功");
                }else {
                    DemoUtil.showToast(getContext(),"初始化失败:" + result.getMessage());
                }
            }
        }, notifyHandler, null);
    }
    private CLMNotifyHandler notifyHandler = new CLMNotifyHandler() {
        @Override
        public void clmUserWasKickedOut(CLMResult result) {
            // 账号被T，需要重新登录
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setMessage("您的账号已经在其他设备登录");
            builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            builder.create().show();
        }
    };
}

package com.huawei.opensdkdemo;

import android.app.Application;

public class DemoApplication extends Application {
    public Application getInstance(){
        return this;
    }
}

package com.huawei.opensdkdemo.sdk;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import com.huawei.cloudlink.openapi.api.CLMCompleteHandler;
import com.huawei.cloudlink.openapi.api.CLMResult;
import com.huawei.cloudlink.openapi.api.CloudLinkSDK;
import com.huawei.opensdkdemo.DemoUtil;
import com.huawei.opensdkdemo.R;

public class CallFragment extends DialogFragment {
    public final static String TAG = "CallFragment";
    View rootView;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        rootView = inflater.inflate(R.layout.sdk_call, container, false);
        Button callBtn = rootView.findViewById(R.id.start_call);
        callBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startCall();
            }
        });
        return rootView;
    }
    private void startCall(){
        TextView numberView = rootView.findViewById(R.id.call_number);
        String number = numberView.getText().toString();
        TextView accountView = rootView.findViewById(R.id.call_account);
        String account = accountView.getText().toString();
        RadioButton audioBtn = rootView.findViewById(R.id.radio_audio);
        boolean isVideo = !audioBtn.isChecked();
        if (TextUtils.isEmpty(number) && TextUtils.isEmpty(account)){
            DemoUtil.showToast(getContext(), "account and number require");
        }
        CloudLinkSDK.getOpenApi().clmCall(number,account, isVideo, new CLMCompleteHandler() {
            @Override
            public void onCompleted(CLMResult result) {
                if (result.getCode() == 0){
                    Log.i(TAG,"call success");
                }else {
                    Log.i(TAG, "call fail:" + result.getMessage());
                    DemoUtil.showToast(getContext(), "呼叫失败："+ result.getMessage());
                }
            }
        });

    }
}

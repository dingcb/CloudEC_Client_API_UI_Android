package com.huawei.opensdkdemo.sdk;

import android.support.v4.app.DialogFragment;

public class ApiPageModel {
    public String name;
    public DialogFragment page;
}
